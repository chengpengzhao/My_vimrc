#!/usr/bin/env sh
../../kana/vim-vspec/bin/vspec ../../kana/vim-vspec . ../../kana/vim-textobj-user t/basices.vim

<div class="layui-container">
    <div class="layui-row" style = "margin-top:2em;">
        <div class="layui-col-lg8 layui-col-md-offset2">
        <center style = "margin-bottom:2em;"><h1>安装完成！（3/3）</h1></center>
        <!-- 安装完成 -->
        <div style = "text-align:center;">
        <div class="layui-btn-group"> 
            <a href="/" class="layui-btn">返回首页</a>
            <a href="/user/login" class="layui-btn">登录后台</a>
            <a class="layui-btn" href="https://doc.xiaoz.me/#/imgurl2/">查看帮助文档</a>
            <a class="layui-btn" href="https://dwz.ovh/imgurl" rel = "nofollow" target = "_blank">打赏支持</a> 
        </div>
        </div>
        <!-- 安装完成END -->
        </div>
    </div>
</div>
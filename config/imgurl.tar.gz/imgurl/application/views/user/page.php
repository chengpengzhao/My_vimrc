<div class="layui-container" style = "margin-top:2em;margin-bottom:4em;">
	<div class="layui-row layui-col-space18">
		<div class="layui-col-lg9">
			<div class = "htmlcontent"><?php echo $content; ?></div>
		</div>
		<div class="layui-col-lg3">
		</div>
	</div>
</div>
